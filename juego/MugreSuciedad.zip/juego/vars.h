//
//  vars.h
//  juegoGC
//
//  baumann jlo 10/28/15.
//

//dimensiones
int MAX_X=150, MAX_Y=150, MAX_Z=500;

//velocidades gotas
const int VEL_G_MIN=2, VEL_G_MAX=5;



